from keras.models import load_model  # TensorFlow is required for Keras to work
from PIL import Image, ImageOps  # Install pillow instead of PIL
import numpy as np
from io import BytesIO
import IPython.display as display
from PIL import Image



def ai_fn(): 
    np.set_printoptions(suppress=True)

    # Load the model
    model = load_model("arabadc\keras_model.h5", compile=False)

    # Load the labels
    class_names = open("arabadc\labels.txt", "r").readlines()

    # Create the array of the right shape to feed into the keras model
    # The 'length' or number of images you can put into the array is
    # determined by the first position in the shape tuple, in this case 1
    data = np.ndarray(shape=(1, 224, 224, 3), dtype=np.float32)

    # Replace this with the path to your image
    image = Image.open("arabadc\images.jpeg").convert("RGB")
    ornek = "arabadc\images.jpeg"

    # resizing the image to be at least 224x224 and then cropping from the center
    size = (224, 224)
    image = ImageOps.fit(image, size, Image.Resampling.LANCZOS)

    # turn the image into a numpy array
    image_array = np.asarray(image)

    # Normalize the image
    normalized_image_array = (image_array.astype(np.float32) / 127.5) - 1

    # Load the image into the array
    data[0] = normalized_image_array

    # Predicts the model
    prediction = model.predict(data)
    index = np.argmax(prediction)
    class_name = class_names[index]
    confidence_score = prediction[0][index]

    # Print prediction and confidence score

    print("Sınıf:", class_name[2:], end="")
    print("Doğruluk Oranı:%", confidence_score*100)

    if "0 Alfa Romeo" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\alfa.jpg")

        print("Kuruluşu 1910 yılında olan Alfa Romeo, Anonima Lombarda Fabbrica Automobili (A.L.F.A) ismiyle Milano‘da kuruldu.24 HP gücünde üretilen ilk araçtan 5 yıl sonra şirketi Nicola Romeo satın aldı ve markanın ismi ALFA ROMEO adını almış oldu. Bugün STELLANTİS otomotiv grubunde yer alan marka, kendine has karakteristik yapısı ile özel bir kullanıcı kitlesi tarafından tercih ediliyor. Ülkemizde Alfa Romeo kullanıcıları ve hayranları kendilerine “Alfisti” ismini veriyor. Genellikle Sportif yapılı ve sürüş zevki yüksek konseptler üzerine yoğunlaşan marka son dönemde SUV modelleri ile kendini göstermeye devam ediyor. Yüksek kaliteli malzemeleri, sürüş odaklı tasarım detayları ile kendine has bir yapısı olan modellerin satışı ülkemizde Koç Holding bünyesinde yapılmaktadır. Alfa Romeo modelleri ise, Tonale, Stelvio, Giulia, Stelvio Quadrifoglio, Giulia Quadrifoglio")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "Kuruluşu 1910 yılında olan Alfa Romeo, Anonima Lombarda Fabbrica Automobili (A.L.F.A) ismiyle Milano‘da kuruldu.24 HP gücünde üretilen ilk araçtan 5 yıl sonra şirketi Nicola Romeo satın aldı ve markanın ismi ALFA ROMEO adını almış oldu. Bugün STELLANTİS otomotiv grubunde yer alan marka, kendine has karakteristik yapısı ile özel bir kullanıcı kitlesi tarafından tercih ediliyor. Ülkemizde Alfa Romeo kullanıcıları ve hayranları kendilerine “Alfisti” ismini veriyor. Genellikle Sportif yapılı ve sürüş zevki yüksek konseptler üzerine yoğunlaşan marka son dönemde SUV modelleri ile kendini göstermeye devam ediyor. Yüksek kaliteli malzemeleri, sürüş odaklı tasarım detayları ile kendine has bir yapısı olan modellerin satışı ülkemizde Koç Holding bünyesinde yapılmaktadır. Alfa Romeo modelleri ise, Tonale, Stelvio, Giulia, Stelvio Quadrifoglio, Giulia Quadrifoglio"
        return sonuc

    elif "1 Aston Martin" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\Aston.jpg")
        
        print("İngiliz otomobil markası Aston Martin, lüks segment otomobil üreten bir markadır. Temelleri 1913 yılına kadar uzanan marka, el işçiliği ile araç üretiyor. Plastik malzemelerin oldukça az kullanılmaya özen gösterildiği araçta pek çok detay alüminyum kullanılarak üretiliyor.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "İngiliz otomobil markası Aston Martin, lüks segment otomobil üreten bir markadır. Temelleri 1913 yılına kadar uzanan marka, el işçiliği ile araç üretiyor. Plastik malzemelerin oldukça az kullanılmaya özen gösterildiği araçta pek çok detay alüminyum kullanılarak üretiliyor."
        return sonuc

    elif "2 Audi" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\Audi.jpeg")
        
        print("Alman kökenli Otomobil Markası AUDİ “Teknoloji ile Bir Adım Önde” mottosu ile tarihi 1899 yılına kadar uzanan bir yolculuğu ifade ediyor. Bugün küresel anlamda otomotiv sektörünü domine edici etkisi ile Almanya’nın en sevilen markalarından biri olarak karşımıza çıkan marka, Volkswagen otomotiv grubu içinde yer alıyor. Premium otomobil modelleri ile ön plana çıkan marka, son dönemde otomobillerinde geliştirdiği elektrifikasyon ile dikkat çekmeye devam ediyor. Sportif modelleri de bünyesinde barındıran marka “RS” isimli versiyonlar ile dinamizmi ön plana çıkartmayı başarıyor.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "Alman kökenli Otomobil Markası AUDİ “Teknoloji ile Bir Adım Önde” mottosu ile tarihi 1899 yılına kadar uzanan bir yolculuğu ifade ediyor. Bugün küresel anlamda otomotiv sektörünü domine edici etkisi ile Almanya’nın en sevilen markalarından biri olarak karşımıza çıkan marka, Volkswagen otomotiv grubu içinde yer alıyor. Premium otomobil modelleri ile ön plana çıkan marka, son dönemde otomobillerinde geliştirdiği elektrifikasyon ile dikkat çekmeye devam ediyor. Sportif modelleri de bünyesinde barındıran marka “RS” isimli versiyonlar ile dinamizmi ön plana çıkartmayı başarıyor."
        return sonuc
    elif "3 Bentley" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\Bentley.jpg")
        
        print("Dünyanın en premium araçlarını üreten markaların başında gelen Bentley, 1919 yılında İngiltere’de kurulmuştur. Tamamen el işçiliği ile üretilen araçlar özel yapımdır. Kullanıcı isteğine göre siparişle üretilen araç pek çok farklı kişiselleştirme imkanı ile kullanıcısının isteklerine göre üretiliyor. Dünyanın en pahalı otomobillerinden olan Bentley modelleri, son dönemde ürettiği SUV modelleri ile dikkat çekmeye devam ediyor.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "Dünyanın en premium araçlarını üreten markaların başında gelen Bentley, 1919 yılında İngiltere’de kurulmuştur. Tamamen el işçiliği ile üretilen araçlar özel yapımdır. Kullanıcı isteğine göre siparişle üretilen araç pek çok farklı kişiselleştirme imkanı ile kullanıcısının isteklerine göre üretiliyor. Dünyanın en pahalı otomobillerinden olan Bentley modelleri, son dönemde ürettiği SUV modelleri ile dikkat çekmeye devam ediyor."
        return sonuc
    elif "4 BMW" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\Bmw.jpg")
        
        print("Premium otomobil denildiği zaman akla ilk gelen bir kaç markadan birisi olan BMW, tarihi 1916 yılına dayanan uzun bir serüven ile bugünlere gelmiş bir Alman otomobil markasıdır. İsmini kurulduğu yer olan Bavyera’ dan alan marka dünyanın en çok tutulan otomobil markalarından birisidir. Özellikle “lüks” algısını kullanıcılarına deneyimlendirmek üzere odaklanan marka, sportif sürüş karakterli “M” modelleri ile de oldukça dikkat çekmektedir. Uçak motoru üreticisi olarak kurulan marka, bugün otomobil ve motosiklet üretimi ile yolculuğuna devam etmektedir. Pek çok yeni teknolojiyi geliştirmek ile beraber elektrikli otomobiller konusunda öncü markalardan biri olmaya adaydır.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "Premium otomobil denildiği zaman akla ilk gelen bir kaç markadan birisi olan BMW, tarihi 1916 yılına dayanan uzun bir serüven ile bugünlere gelmiş bir Alman otomobil markasıdır. İsmini kurulduğu yer olan Bavyera’ dan alan marka dünyanın en çok tutulan otomobil markalarından birisidir. Özellikle “lüks” algısını kullanıcılarına deneyimlendirmek üzere odaklanan marka, sportif sürüş karakterli “M” modelleri ile de oldukça dikkat çekmektedir. Uçak motoru üreticisi olarak kurulan marka, bugün otomobil ve motosiklet üretimi ile yolculuğuna devam etmektedir. Pek çok yeni teknolojiyi geliştirmek ile beraber elektrikli otomobiller konusunda öncü markalardan biri olmaya adaydır."
        return sonuc
    elif "5 Bugatti" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\Bugatti.jpg")
        
        print("1909 yılında kurulan marka, performans odaklı otomobiller üretiyor. El işçiliği ile özel olarak üretilen otomobiller dünyanın en hızlı otomobillerin başında geliyor. Almanya’da üretilen otomobiller genellikle 2 kişilik yarış arabaları tasarımı ile üretiliyor. Bununla beraber üst sınıf kaliteli malzeme ile üretilen araçlar oldukça lüks yapıya sahip.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "1909 yılında kurulan marka, performans odaklı otomobiller üretiyor. El işçiliği ile özel olarak üretilen otomobiller dünyanın en hızlı otomobillerin başında geliyor. Almanya’da üretilen otomobiller genellikle 2 kişilik yarış arabaları tasarımı ile üretiliyor. Bununla beraber üst sınıf kaliteli malzeme ile üretilen araçlar oldukça lüks yapıya sahip."
        return sonuc
    elif "6 Buick" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\Buick.jpg")
        
        print("Amerika üretimi olan Buick, tarihi 1899 yılına kadar giden bir otomobil markasıdır. Markanın ana pazarı Çin’dir. General motor bünyesinde olan marka 1950’li yıllardan sonra büyük ve geniş modelleri ile ilgi çekmiştir. Bugün nostaljik olarak büyük bir hayran kitlesi olan markanın, konforlu otomobilleri ile dikkat çekmektedir.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "Amerika üretimi olan Buick, tarihi 1899 yılına kadar giden bir otomobil markasıdır. Markanın ana pazarı Çin’dir. General motor bünyesinde olan marka 1950’li yıllardan sonra büyük ve geniş modelleri ile ilgi çekmiştir. Bugün nostaljik olarak büyük bir hayran kitlesi olan markanın, konforlu otomobilleri ile dikkat çekmektedir."
        return sonuc
    elif "7 Cadillac" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\cadillac.jpg")
        
        print("1902 yılında kurulan Cadillac, Amerikan menşeili bir marka olarak doğduğu yer olan bölgede oldukça popüler bir markadır. Lüks otomobil markası, General motor bünyesinde bulunmaktadır. Bugün elektrikli araçlar ve özellikle SUV sınıfı araçlarda popülerlik sağlayan marka, güçlü bir imaja sahiptir.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "1902 yılında kurulan Cadillac, Amerikan menşeili bir marka olarak doğduğu yer olan bölgede oldukça popüler bir markadır. Lüks otomobil markası, General motor bünyesinde bulunmaktadır. Bugün elektrikli araçlar ve özellikle SUV sınıfı araçlarda popülerlik sağlayan marka, güçlü bir imaja sahiptir."
        return sonuc
    elif "8 Chery" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\chery.jpg")
        
        print("Çin merkezli bir otomobil markası olan Chery, ülkemizde satış da olan bir firmadır. Türkiye’de Mermerler Oto distribütörlüğünde satılan otomobiller, 1997 yılında kurulmuştur. Yeni modelleri ile ülkemizde satış da olmaya devam edecektir. SUV ve binek modelleri ile uygun fiyatlı bir politika izlemektedir.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "Çin merkezli bir otomobil markası olan Chery, ülkemizde satış da olan bir firmadır. Türkiye’de Mermerler Oto distribütörlüğünde satılan otomobiller, 1997 yılında kurulmuştur. Yeni modelleri ile ülkemizde satış da olmaya devam edecektir. SUV ve binek modelleri ile uygun fiyatlı bir politika izlemektedir."
        return sonuc
    elif "9 Chevrolet" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\chevrolet.jpg")
        
        print("Chevy veya Chevrolet Division of General Motors Company, 1911'de kurulmuş olan ABD merkezli bir otomobil şirketidir. Adını Kurucusu Louis Chevrolet'in soyadından almaktadır. 1918'de %54.6'sını satın alan General Motors bünyesine geçmiştir.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "Chevy veya Chevrolet Division of General Motors Company, 1911'de kurulmuş olan ABD merkezli bir otomobil şirketidir. Adını Kurucusu Louis Chevrolet'in soyadından almaktadır. 1918'de %54.6'sını satın alan General Motors bünyesine geçmiştir."
        return sonuc
    elif "10 Chrysler" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\chrysler.jpeg")
        
        print("1925 yılında kurulan marka, 1930 yılında Dodge markasına satılmıştır. Bugün Stellantis otomotiv gurubunda yer alan marka premium sınıf otomobiller üretmektedir.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "1925 yılında kurulan marka, 1930 yılında Dodge markasına satılmıştır. Bugün Stellantis otomotiv gurubunda yer alan marka premium sınıf otomobiller üretmektedir."
        return sonuc
    elif "11 Cupra" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\cupra.jpg")
        
        print("Seat markasına bağlı olarak bir versiyon olarak serüvenine başlayan Cupra, bugün bağımsız bir otomobil markası olarak otomobil üretmeye devam ediyor. Seat markasının daha sportif bir versiyonu olarak yüksek performans sunan modeller ile satılmaya başlanan Cupra, bugün 3 farklı model ile ülkemizde satılıyor. Formentor, Leon ve Ateca modellerini ülkemizde satan marka Doğuş grubu bünyesinde satılıyor. Motor şanzıman ünitelerini SEAT markasından yani dolayısıyla Alman üretici Volkswagen grubundan alan CUPRA, tasarım detayları ile sportif modeller üretmektedir.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "Seat markasına bağlı olarak bir versiyon olarak serüvenine başlayan Cupra, bugün bağımsız bir otomobil markası olarak otomobil üretmeye devam ediyor. Seat markasının daha sportif bir versiyonu olarak yüksek performans sunan modeller ile satılmaya başlanan Cupra, bugün 3 farklı model ile ülkemizde satılıyor. Formentor, Leon ve Ateca modellerini ülkemizde satan marka Doğuş grubu bünyesinde satılıyor. Motor şanzıman ünitelerini SEAT markasından yani dolayısıyla Alman üretici Volkswagen grubundan alan CUPRA, tasarım detayları ile sportif modeller üretmektedir."
        return sonuc
    elif "12 Dacia" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\dacia.jpeg")
        
        print("Romanya‘da kurulan Dacia “Ulaşılabilir Otomobil” mottosu ile uygun fiyatlı ve aynı zamanda kaliteli otomobiller üretmek üzere yaşamına başlamış bir markadır. Dacia 1999 yılında Renault markası bünyesine girmiştir. Ülkemizde uygun fiyatlı otomobil satın almak isteyen kullanıcılar tarafında ağırlıkta tercih edilen model, ülkemizde artan araç fiyatları neticesinde bu özelliğini kaybetmiştir. Yenilenen logosu ile tasarım anlamında daha ilgi çekici modeller ile ülkemizde satılan Dacia modelleri, ticari modelleri ile de ülkemizde tercih ediliyor.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "Romanya‘da kurulan Dacia “Ulaşılabilir Otomobil” mottosu ile uygun fiyatlı ve aynı zamanda kaliteli otomobiller üretmek üzere yaşamına başlamış bir markadır. Dacia 1999 yılında Renault markası bünyesine girmiştir. Ülkemizde uygun fiyatlı otomobil satın almak isteyen kullanıcılar tarafında ağırlıkta tercih edilen model, ülkemizde artan araç fiyatları neticesinde bu özelliğini kaybetmiştir. Yenilenen logosu ile tasarım anlamında daha ilgi çekici modeller ile ülkemizde satılan Dacia modelleri, ticari modelleri ile de ülkemizde tercih ediliyor."
        return sonuc
    elif "13 Daewoo" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\daewoo.jpg")
        
        print("Güney Koreli üretici Daewoo 1967 yılında kurulmuştur. Genellikle sedan modeller üreten marka 1999 yılında iflas etmiştir. General Motor tarafından satın alınan marka, GM Daewoo olarak yaşantısına devam etmektedir.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "Güney Koreli üretici Daewoo 1967 yılında kurulmuştur. Genellikle sedan modeller üreten marka 1999 yılında iflas etmiştir. General Motor tarafından satın alınan marka, GM Daewoo olarak yaşantısına devam etmektedir."
        return sonuc
    elif "14 Daihatsu" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\daihatsu.jpg")
        
        print("1907 yılında kurulan Daihatsu, Japonya’da kurulmuştur. Genel merkez kararı ile 2012 yılından beri sıfır otomobil satışı Türkiye’de olmayan markanın, yedek parça ve servis desteği ülkemizde devam etmektedir. SUV, spor otomobil ve ticari araçlar üreten markanın ülkemizde özellikle SUV modelleri tercih edilmektedir.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "1907 yılında kurulan Daihatsu, Japonya’da kurulmuştur. Genel merkez kararı ile 2012 yılından beri sıfır otomobil satışı Türkiye’de olmayan markanın, yedek parça ve servis desteği ülkemizde devam etmektedir. SUV, spor otomobil ve ticari araçlar üreten markanın ülkemizde özellikle SUV modelleri tercih edilmektedir."
        return sonuc
    elif "15 Dodge" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\dodge.jpg")
        
        print("Amerikan markası olan Dodge, 1914 yılında kurulmuştur. Ford Model T için parça üreten marka daha sonrasında küçük şehir otomobilleri üretmeye başlamıştır. Bugün Stellantis otomotiv grubunda yer alan marka, güçlü motorlu pick-up modelleri ve spor otomobiller üretmektedir. Döneminde üretilen yüksek hacimli otomobiller ile bugün nostaljik anlamda oldukça çok seveni vardır.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "Amerikan markası olan Dodge, 1914 yılında kurulmuştur. Ford Model T için parça üreten marka daha sonrasında küçük şehir otomobilleri üretmeye başlamıştır. Bugün Stellantis otomotiv grubunda yer alan marka, güçlü motorlu pick-up modelleri ve spor otomobiller üretmektedir. Döneminde üretilen yüksek hacimli otomobiller ile bugün nostaljik anlamda oldukça çok seveni vardır."
        return sonuc
    elif "16 DS Automobiles" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\ds.jpg")
        
        print("DS Automobiles 2014 yılında bağımsız bir marka olmuştur. Citroen markasının ve dahası PSA grubu otomobil yapılanmasının “premium” otomobil üreten versiyonu olarak ortaya çıkmıştır. Fransız kökenli marka, Citroen yetkili satıcılarında satılırken pek çok yerde kendi showroomlarında satılmaya devam etmektedir. DS markası bugün için Stellantis otomotiv grubu içinde yer almaktadır.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "DS Automobiles 2014 yılında bağımsız bir marka olmuştur. Citroen markasının ve dahası PSA grubu otomobil yapılanmasının “premium” otomobil üreten versiyonu olarak ortaya çıkmıştır. Fransız kökenli marka, Citroen yetkili satıcılarında satılırken pek çok yerde kendi showroomlarında satılmaya devam etmektedir. DS markası bugün için Stellantis otomotiv grubu içinde yer almaktadır."
        return sonuc
    elif "17 Ferrari" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\Ferrari.jpg")
        
        print("İtalya’nın Modena şehrinde kurulan Ferrari, otomotiv endüstrisi içinde önemli bir yere sahiptir. Tarihi boyunca supersport yarış araçları üreten marka, hız tutkunları için tercih edilen bir markadır. Markanın yaratıcısı Enzo Ferrari tarihi açısından oldukça önemlidir.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "İtalya’nın Modena şehrinde kurulan Ferrari, otomotiv endüstrisi içinde önemli bir yere sahiptir. Tarihi boyunca supersport yarış araçları üreten marka, hız tutkunları için tercih edilen bir markadır. Markanın yaratıcısı Enzo Ferrari tarihi açısından oldukça önemlidir."
        return sonuc
    elif "18 Fiat" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\Fiat.jpg")
        
        print("1899 yılında ilk olarak temelleri Torino’da atılan Fiat, ismini kurulduğu bölgeden almıştır. (Fabbrica Italiana Automobili Torino) Bünyesinde Lancia, Alfa Romeo, Maserati, Chrysler, Dodge, Jeep, Yamaha Motor Company, Iveco, Ferrari gibi markaları barındırmaktadır. Son dönemde Fiat ve bünyesindeki markalarda yeni bir oluşum içine girmiştir ve Stellantis otomotiv grubu bünyesine katılmıştır.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "1899 yılında ilk olarak temelleri Torino’da atılan Fiat, ismini kurulduğu bölgeden almıştır. (Fabbrica Italiana Automobili Torino) Bünyesinde Lancia, Alfa Romeo, Maserati, Chrysler, Dodge, Jeep, Yamaha Motor Company, Iveco, Ferrari gibi markaları barındırmaktadır. Son dönemde Fiat ve bünyesindeki markalarda yeni bir oluşum içine girmiştir ve Stellantis otomotiv grubu bünyesine katılmıştır."
        return sonuc
    elif "19 Ford" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\Ford.jpg")
        
        print("1903 yılında kurulan Ford Motor Company, Henry Ford tarafından kurulmuş ve ismini almıştır. Amerikan markası olan Ford, Avrupa’dada üretim yapmaktadır. Aynı zamanda Koç holding bünyesinde 1950’li yıllardan beri ülkemizde de üretim yapılmaktadır. Ford Otosan adıyla kurulan Koç Holding şirketi, bugün tüm dünyaya özellikle ticari araç özelinde ihracat yapmaktadır.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "1903 yılında kurulan Ford Motor Company, Henry Ford tarafından kurulmuş ve ismini almıştır. Amerikan markası olan Ford, Avrupa’dada üretim yapmaktadır. Aynı zamanda Koç holding bünyesinde 1950’li yıllardan beri ülkemizde de üretim yapılmaktadır. Ford Otosan adıyla kurulan Koç Holding şirketi, bugün tüm dünyaya özellikle ticari araç özelinde ihracat yapmaktadır."
        return sonuc
    elif "20 Geely" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\geely.jpg")
        
        print("1986 yılında Çin’de kurulan Geely, otomobil, motosiklet, motor ve şanzıman üretimi yapan şirket, ülkemizde sedan otomobil modelleri ile satıştadır. Apple ile anlaşma yaparak gücüne güç katan marka, Apple Car Play’i araçlarında ilk kullanan markadır. Bununla beraber Volvo markasını da 2010 yılında Ford’dan satın almıştır.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "1986 yılında Çin’de kurulan Geely, otomobil, motosiklet, motor ve şanzıman üretimi yapan şirket, ülkemizde sedan otomobil modelleri ile satıştadır. Apple ile anlaşma yaparak gücüne güç katan marka, Apple Car Play’i araçlarında ilk kullanan markadır. Bununla beraber Volvo markasını da 2010 yılında Ford’dan satın almıştır."
        return sonuc
    elif "21 Honda" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\Honda.jpg")
        
        print("Japon otomobili denildiği zaman akla ilk gelen markaların başında gelen Honda, 1948 yılında Tokyo/Japonya‘da kurulmuştur. Sağlamlık ve uzun ömürlülük konusunda ün yapan marka, konforlu otomobiller ile beraber sportif kullanıma uygun versiyonlu araçlar ile ciddi bir hayran kitlesine sahiptir.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "Japon otomobili denildiği zaman akla ilk gelen markaların başında gelen Honda, 1948 yılında Tokyo/Japonya‘da kurulmuştur. Sağlamlık ve uzun ömürlülük konusunda ün yapan marka, konforlu otomobiller ile beraber sportif kullanıma uygun versiyonlu araçlar ile ciddi bir hayran kitlesine sahiptir."
        return sonuc
    elif "22 Hyundai" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\hyundai.jpg")
        
        print("Güney Kore merkezli Hyundai, Gemi ve iş makinası üretimi gibi pek çok farklı alanda üretim yapan bir şirkettir. 1967 yılında Seul, Güney Kore’de kurulmuştur. Türkçe karşılığı çağdaş ve modern anlamına gelen Hyundai, Kia ile kardeş şirketlerdir. Elektrikli araçlar konusunda oldukça iddialı çalışmalar yapan marka, Accent modeli Hyundai için bir dönüm noktası olmuştur. Genesis isimli lüks segment otomobil üreten bir yan markası da vardır.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "Güney Kore merkezli Hyundai, Gemi ve iş makinası üretimi gibi pek çok farklı alanda üretim yapan bir şirkettir. 1967 yılında Seul, Güney Kore’de kurulmuştur. Türkçe karşılığı çağdaş ve modern anlamına gelen Hyundai, Kia ile kardeş şirketlerdir. Elektrikli araçlar konusunda oldukça iddialı çalışmalar yapan marka, Accent modeli Hyundai için bir dönüm noktası olmuştur. Genesis isimli lüks segment otomobil üreten bir yan markası da vardır."
        return sonuc
    elif "23 İnfiniti" in class_name:
        print("TAHMİNİM:arabadc\sonuclar/infiniti.jpg")
        
        print("Nissan Motors’a bağlı lüks otomobil markası olan İnfiniti, ülkemizde özellikle SUV modelleri tercih edilen markanın pek çok dünya ülkesinde satışı mevcuttur.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "Nissan Motors’a bağlı lüks otomobil markası olan İnfiniti, ülkemizde özellikle SUV modelleri tercih edilen markanın pek çok dünya ülkesinde satışı mevcuttur."
        return sonuc
    elif "24 Isuzu" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\ısuzu.jpg")
        
        print("Japonya merkezli bir otomobil markası olan Isuzu özellikle motor dayanıklılığı ile meşhur bir markadır. Özellikle ticari araç grubunda araç üretimi yapan markanın, D-Max isimli Pick-Up modeli oldukça popülerdir. Toplu taşıma, turizm, kamyon ve kamyonet tarzında modelleri vardır.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "Japonya merkezli bir otomobil markası olan Isuzu özellikle motor dayanıklılığı ile meşhur bir markadır. Özellikle ticari araç grubunda araç üretimi yapan markanın, D-Max isimli Pick-Up modeli oldukça popülerdir. Toplu taşıma, turizm, kamyon ve kamyonet tarzında modelleri vardır."
        return sonuc
    elif "25 İVECO" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\iveco.jpg")
        
        print("İtalya merkezli ticari araç markası olan Iveco, dünya çapında ticari araç satışı yapmaktadır. Aynı zamanda dizel motor üretimi yapan marka, tır kamyon ve kamyonet satışı yapmaktır.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "İtalya merkezli ticari araç markası olan Iveco, dünya çapında ticari araç satışı yapmaktadır. Aynı zamanda dizel motor üretimi yapan marka, tır kamyon ve kamyonet satışı yapmaktır."
        return sonuc
    elif "26 Jaguar" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\jaguar.jpg")
        
        print("İngiltere merkezli otomobil markası olan Jaguar, tarihi 1922 yılına kadar gidiyor. Şuan ki sahibi Hindistanlı üretici Tata olan marka, premium sınıf araç üreten bir markadır. Lüks algısı yüksek modeller üreten Jaguar, sportif karakterli yüksek performans gücüne sahip otomobiller üretir.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "İngiltere merkezli otomobil markası olan Jaguar, tarihi 1922 yılına kadar gidiyor. Şuan ki sahibi Hindistanlı üretici Tata olan marka, premium sınıf araç üreten bir markadır. Lüks algısı yüksek modeller üreten Jaguar, sportif karakterli yüksek performans gücüne sahip otomobiller üretir."
        return sonuc
    elif "27 Jeep" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\Jeep.jpg")
        
        print("Askeri amaçlı araç ve motosiklet üretimi ile yaşamına başlayan Jeep 1940’lı yıllarda kurulmuştur. Sağlam, dayanıklı ve uzun ömürlü araçlar üretmek amacıyla tasarlanan Jeep modelleri bugün gelinen noktada, daha lüks ve konforlu araçlar üretmektedir. SUV sınıfında araçlar üreten marka, Stellantis otomobil grubunda yer almaktadır.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "Askeri amaçlı araç ve motosiklet üretimi ile yaşamına başlayan Jeep 1940’lı yıllarda kurulmuştur. Sağlam, dayanıklı ve uzun ömürlü araçlar üretmek amacıyla tasarlanan Jeep modelleri bugün gelinen noktada, daha lüks ve konforlu araçlar üretmektedir. SUV sınıfında araçlar üreten marka, Stellantis otomobil grubunda yer almaktadır."
        return sonuc
    elif "28 KIA" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\kia.jpg")
        
        print("1944 yılında Seul-Güney Kore’de kurulan Kia, Hyundai markası ile kardeş firmadır. Özellikle Amerikan pazarında popüler olan marka, Türkiye’de binek, SUV ve ticari araçları ile tercih edilmektedir. Kia’nın Türkiye’deki disbiritörlüğünü ise Çelik Motor yapmaktadır. Hibrit, beniznli ve dizel motor üniteleri ile otomobil satan marka, konfor odaklı otomobiller tasarlar.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "1944 yılında Seul-Güney Kore’de kurulan Kia, Hyundai markası ile kardeş firmadır. Özellikle Amerikan pazarında popüler olan marka, Türkiye’de binek, SUV ve ticari araçları ile tercih edilmektedir. Kia’nın Türkiye’deki disbiritörlüğünü ise Çelik Motor yapmaktadır. Hibrit, beniznli ve dizel motor üniteleri ile otomobil satan marka, konfor odaklı otomobiller tasarlar."
        return sonuc
    elif "29 Lada" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\lada.jpg")
        
        print("Rusya merkezli bir marka olan Lada, geçmişten bugüne ikonik bir model haline gelen Niva modeli ile bilinmektedir. Sağlamlığı ile ön plana çıkan Niva modeli, uzunca bir dönem aynı tasarıma bağlı kalarak yolculuğuna devam etmektedir. 4×4 bir arazi aracı satın almak isteyen kullanıcıların uygun fiyatlı olması nedeniyle tercih ettiği model, son yıllarda bir yenilenme sürecine girmiştir. Lada markasının Vesta, Samara gibi binek araç modelleri de mevcuttur.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "Rusya merkezli bir marka olan Lada, geçmişten bugüne ikonik bir model haline gelen Niva modeli ile bilinmektedir. Sağlamlığı ile ön plana çıkan Niva modeli, uzunca bir dönem aynı tasarıma bağlı kalarak yolculuğuna devam etmektedir. 4×4 bir arazi aracı satın almak isteyen kullanıcıların uygun fiyatlı olması nedeniyle tercih ettiği model, son yıllarda bir yenilenme sürecine girmiştir. Lada markasının Vesta, Samara gibi binek araç modelleri de mevcuttur."
        return sonuc
    elif "30 Lamborghini" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\lamborghini.jpg")
        
        print("1963 yılında kurulan Lamborghini, supersport otomobil üreten bir İtalyan otomobil üreticisidir. Şuandaki sahibi Volkswagen grup olan marka üretim hayatına traktör üreterek başlamıştır. Dünyanın en pahalı ve lüks otomobil modellerini üretmek konusunda vizyon edinen marka, süper hızlı modeller üretmektedir.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "1963 yılında kurulan Lamborghini, supersport otomobil üreten bir İtalyan otomobil üreticisidir. Şuandaki sahibi Volkswagen grup olan marka üretim hayatına traktör üreterek başlamıştır. Dünyanın en pahalı ve lüks otomobil modellerini üretmek konusunda vizyon edinen marka, süper hızlı modeller üretmektedir."
        return sonuc
    elif "31 Lancia" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\lancia.jpg")
        
        print("1906 yılında kurulan Lancia, 1969 yılından beri Fiat markasının çatısı altındadır. Ülkemizde de bir dönem satışta olan marka şuan için satış yapmamakla beraber yedek parça ve servis konusunda işlemlerine devam etmektedir.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "1906 yılında kurulan Lancia, 1969 yılından beri Fiat markasının çatısı altındadır. Ülkemizde de bir dönem satışta olan marka şuan için satış yapmamakla beraber yedek parça ve servis konusunda işlemlerine devam etmektedir."
        return sonuc
    elif "32 Land Rover" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\land.jpg")
        
        print("İngiliz otomobil üreticisi Land Rover, 2008 yılında Hindistanlı otomobil üreticisi Tata’ya satılmıştır. Premium sıfır SUV modelleri üreten marka, “lüks SUV” denildiği zaman ülkemizde ilk akla gelen markalardan birisidir. Kuruluşu ikinci dünya savaşı yıllarına dayanan marka ilk dönemlerde askeri yeteneği olan, sağlam ve arazi kabiliyeti yüksek modeller üretmiştir. Zaman içinde ikonik bir tarz yakalayan Defender modeli Land Rover modelleri içinde en bilinen araçlardandır.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "İngiliz otomobil üreticisi Land Rover, 2008 yılında Hindistanlı otomobil üreticisi Tata’ya satılmıştır. Premium sıfır SUV modelleri üreten marka, “lüks SUV” denildiği zaman ülkemizde ilk akla gelen markalardan birisidir. Kuruluşu ikinci dünya savaşı yıllarına dayanan marka ilk dönemlerde askeri yeteneği olan, sağlam ve arazi kabiliyeti yüksek modeller üretmiştir. Zaman içinde ikonik bir tarz yakalayan Defender modeli Land Rover modelleri içinde en bilinen araçlardandır."
        return sonuc
    elif "33 Lexus" in class_name:
        print(" TAHMİNİM:arabadc\sonuclar\lexus.jpg")
        print("Japonya merkezli otomobil markası olan Toyota’nın lüks segment araç üreten markası olan Lexus, özellikle Ortadoğu ve Amerikan pazarında popüler bir markadır. Lüks sınıf sedan modelleri ile tanınmaktadır. Amerika’da “en sağlam otomobil” ödülünü uzunca zamandır elinde tutan model, Japon otomobili Toyota’nın sağlamlık imajını üstüne koyarak geliştirmektedir.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "Japonya merkezli otomobil markası olan Toyota’nın lüks segment araç üreten markası olan Lexus, özellikle Ortadoğu ve Amerikan pazarında popüler bir markadır. Lüks sınıf sedan modelleri ile tanınmaktadır. Amerika’da “en sağlam otomobil” ödülünü uzunca zamandır elinde tutan model, Japon otomobili Toyota’nın sağlamlık imajını üstüne koyarak geliştirmektedir."
        return sonuc
    elif "34 Lincoln" in class_name:
        print(" TAHMİNİM:arabadc\sonuclar\lincoln.jpg")
        print("Amerika markası olan Lincoln, lüks sınıf araç üretimi yapmaktadır. Cadillac markası ile rekabet halinde olan marka, üretiminin neredeyse tamamını Amerikan pazarına ayırmaktadır. Ülkemizde satışta olmayan Lincoln büyük hacimli motorları nedeniyle de ülkemizde tercih edilemiyor.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "Amerika markası olan Lincoln, lüks sınıf araç üretimi yapmaktadır. Cadillac markası ile rekabet halinde olan marka, üretiminin neredeyse tamamını Amerikan pazarına ayırmaktadır. Ülkemizde satışta olmayan Lincoln büyük hacimli motorları nedeniyle de ülkemizde tercih edilemiyor."
        return sonuc
    elif "35 Lotus" in class_name:
        print(" TAHMİNİM:arabadc\sonuclar\lotus.jpg")
        print("1952 yılında Londra İngiltere’de kurulan otomobil markası Lotus, bugün elektrikli araç üretimi ile yeni modellerini piyasaya sürmektedir. 600 km menzil sunan elektrikli SUV modeli 0-100 km/h hızlanmasını 2.95 saniyede tamamlamaktadır. Ülkemizde satışta olmayan model, supersport modeller ve SUV araçlar üretmektedir.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "1952 yılında Londra İngiltere’de kurulan otomobil markası Lotus, bugün elektrikli araç üretimi ile yeni modellerini piyasaya sürmektedir. 600 km menzil sunan elektrikli SUV modeli 0-100 km/h hızlanmasını 2.95 saniyede tamamlamaktadır. Ülkemizde satışta olmayan model, supersport modeller ve SUV araçlar üretmektedir."
        return sonuc
       
    elif "36 Maserati" in class_name:
        print(" TAHMİNİM:arabadc\sonuclar\maserati.jpg ")
        print(" İtalyan otomobil markası Maserati, spor otomobil üreten bir markadır. 1914 yılında kurulan marka, 1993 yılında Ferrari ile birlikte Fiat tarafından satın alındı. Yüksek motor gücüne sahip dinamizmi yüksek modeller üreten markanın lüks algısı oldukça yüksektir.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "İtalyan otomobil markası Maserati, spor otomobil üreten bir markadır. 1914 yılında kurulan marka, 1993 yılında Ferrari ile birlikte Fiat tarafından satın alındı. Yüksek motor gücüne sahip dinamizmi yüksek modeller üreten markanın lüks algısı oldukça yüksektir."
        return sonuc
    elif "37 Mazda" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\mazda.jpg")
        
        print("1920 yılında Fuchū, Hiroshima Prefektörlüğü, Japonya'da kurulan çok uluslu Japon otomobil üreticisidir.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "1920 yılında Fuchū, Hiroshima Prefektörlüğü, Japonya'da kurulan çok uluslu Japon otomobil üreticisidir."
        return sonuc
    elif "38 Mclaren" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\mclaren.jpg")
        
        print("Dünyaca ünlü supersport otomobil üreticisi Mclaren, İngiltere merkezli bir otomobil markasıdır. Dünyanın en hızlı modellerini üretmeye aday marka, yarış sporlarında vazgeçilmez bir marka haline gelmiştir.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "Dünyaca ünlü supersport otomobil üreticisi Mclaren, İngiltere merkezli bir otomobil markasıdır. Dünyanın en hızlı modellerini üretmeye aday marka, yarış sporlarında vazgeçilmez bir marka haline gelmiştir."
        return sonuc
    elif "39 Mercedes" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\mercedes.jpg")
        
        print("Almanya’nın en ünlü otomobil markalarının başında gelen Mercedes-Benz tüm dünyada kabul görmüş lüks sınıf otomobiller üreten bir markadır. 1926 yılında kurulan marka içten yanmalı motorun temellerini atmakla beraber otomobil endüstrisine büyük katkıları olmuştur. Dünyanın en uzun yolculuğunu yapan, fren balatasını bulan önemli bir markadır. tarihsel katkısının yanında ticari araç sınıfında da Mercedes-Benz bir tercih olmuştur.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "Almanya’nın en ünlü otomobil markalarının başında gelen Mercedes-Benz tüm dünyada kabul görmüş lüks sınıf otomobiller üreten bir markadır. 1926 yılında kurulan marka içten yanmalı motorun temellerini atmakla beraber otomobil endüstrisine büyük katkıları olmuştur. Dünyanın en uzun yolculuğunu yapan, fren balatasını bulan önemli bir markadır. tarihsel katkısının yanında ticari araç sınıfında da Mercedes-Benz bir tercih olmuştur."
        return sonuc
    elif "40 MG" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\mg.jpg")
        
        print("İngiltere’de kurulan MG markasının tarihi 1924 yılına kadar uzanıyor. Bugün ülkemizde de satış da olan marka, elektrikli ve benzinli motor ünitelerine sahip SUV modelleri ile satılıyor.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "İngiltere’de kurulan MG markasının tarihi 1924 yılına kadar uzanıyor. Bugün ülkemizde de satış da olan marka, elektrikli ve benzinli motor ünitelerine sahip SUV modelleri ile satılıyor."
        return sonuc
    elif "41 MINI" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\mini.jpg")
        
        print("Kült bir yapısı olan Mini, küçük spor araçlar üreten bir otomobil markasıdır. 1960’lı yıllardan bu yana varlığını sürdüren Mini tarihi boyunca ikonik tasarım detaylarını korumuş ve bugün o günlerden izler taşıyan araçlar üreterek tasarım diline bağlı kalmıştır. İngiltere’de kurulan marka ilerleyen dönemlerde BMW çatısı altına girmiştir ve bugün hala BMW grubunun bir parçasıdır. Retro tasarım detaylarına sahip markanın binek otomobil sınıfında araçları vardır ve SUV modellerine ek olarak hatchback karoser seçeneğine sahip modelleri mevcuttur.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "Kült bir yapısı olan Mini, küçük spor araçlar üreten bir otomobil markasıdır. 1960’lı yıllardan bu yana varlığını sürdüren Mini tarihi boyunca ikonik tasarım detaylarını korumuş ve bugün o günlerden izler taşıyan araçlar üreterek tasarım diline bağlı kalmıştır. İngiltere’de kurulan marka ilerleyen dönemlerde BMW çatısı altına girmiştir ve bugün hala BMW grubunun bir parçasıdır. Retro tasarım detaylarına sahip markanın binek otomobil sınıfında araçları vardır ve SUV modellerine ek olarak hatchback karoser seçeneğine sahip modelleri mevcuttur."
        return sonuc
    elif "42 Mitsubishi" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\mitsu.jpg")
        
        print("Türkiye’deki ortaklığını Temsa ile yapan Mitsubishi 1970 yılında Japonya’da kurulmuştur. Japon otomobil markası ürettiği otomobiller ile sağlamlık ve uzun ömürlülük konusunda ün kazanmayı başarmıştır. Binek, SUV ve Pick-Up modellerine ek olarak ticari araç sınıfında da oldukça tercih edilmiştir. Motor sporlarında yarış otomobilleri ile başarılı işler yapmayı başaran Mitsubishi, Nisan-Renault ortaklığına dahil olmuştur.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "Türkiye’deki ortaklığını Temsa ile yapan Mitsubishi 1970 yılında Japonya’da kurulmuştur. Japon otomobil markası ürettiği otomobiller ile sağlamlık ve uzun ömürlülük konusunda ün kazanmayı başarmıştır. Binek, SUV ve Pick-Up modellerine ek olarak ticari araç sınıfında da oldukça tercih edilmiştir. Motor sporlarında yarış otomobilleri ile başarılı işler yapmayı başaran Mitsubishi, Nisan-Renault ortaklığına dahil olmuştur."
        return sonuc
    elif "43 Nissan" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\issan.jpg")
        
        print("Japonya‘da kurulan Nissan, arazi araçları, yarış otomobilleri, binek ve pick-up gibi pek çok farklı segment ve karoserdeki modelleri ile sağlam ve dayanıklı modeller üretmiştir. 1910 yılına kadar uzanan tarihi boyunca yukarı ivmesini sürdürmeyi başaran Nissan, Renault ile uzun yıllardır süren ortaklığı devam etmektedir. Ortak motor-şanzıman kombinasyonlarını kullanan Nissan ve Renault özellikle dizel motor ünitesi olan “DCİ” motor ile oldukça popülarite yakalamıştır.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "Japonya‘da kurulan Nissan, arazi araçları, yarış otomobilleri, binek ve pick-up gibi pek çok farklı segment ve karoserdeki modelleri ile sağlam ve dayanıklı modeller üretmiştir. 1910 yılına kadar uzanan tarihi boyunca yukarı ivmesini sürdürmeyi başaran Nissan, Renault ile uzun yıllardır süren ortaklığı devam etmektedir. Ortak motor-şanzıman kombinasyonlarını kullanan Nissan ve Renault özellikle dizel motor ünitesi olan “DCİ” motor ile oldukça popülarite yakalamıştır."
        return sonuc
    elif "44 Opel" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\opel.jpg")
        
        print("Alman otomobil markası Opel, 1917 yılındaki kuruluşundan 2017 yılına kadar Alman General Motors’un idi. 2017 yılında ise Stellantis otomobil grubuna dahil oldu. Binek, SUV ve ticari otomobiller üreten marka, pek çok ülkede satış da ve ciddi bir pazar payına sahip. İngiliz Vauxhall markası ise Opel’in kardeş markasıdır.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "Alman otomobil markası Opel, 1917 yılındaki kuruluşundan 2017 yılına kadar Alman General Motors’un idi. 2017 yılında ise Stellantis otomobil grubuna dahil oldu. Binek, SUV ve ticari otomobiller üreten marka, pek çok ülkede satış da ve ciddi bir pazar payına sahip. İngiliz Vauxhall markası ise Opel’in kardeş markasıdır."
        return sonuc
    elif "45 Peugeot" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\pejo.jpg")
        
        print("Fransız otomobil markası Peugeot, tarihi 1890 yılına kadar uzanmaktadır. Bugün Stellantis otomotiv grubunun içinde yer alan Peugeot uzun yıllardır içinde olduğu PSA grubunu bu şekilde güncellemiş oldu. Binek, SUV, hafif ticari gibi pek çok sınıfta araç üreten marka elektrikli otomobil üretimi konusunda ciddi yatırımlar yapmaya devam ediyor.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "Fransız otomobil markası Peugeot, tarihi 1890 yılına kadar uzanmaktadır. Bugün Stellantis otomotiv grubunun içinde yer alan Peugeot uzun yıllardır içinde olduğu PSA grubunu bu şekilde güncellemiş oldu. Binek, SUV, hafif ticari gibi pek çok sınıfta araç üreten marka elektrikli otomobil üretimi konusunda ciddi yatırımlar yapmaya devam ediyor."
        return sonuc
    elif "46 Porsche" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\porş.jpg")
        
        print("Sportif araç deneyimi denildiği zaman ilk akla gelen markaların başında olan Alman otomobil markası Posche, 1931 yılında kurulmuştur. Bugün Volkswagen AG çatısında bulunan lüks otomobil markası, Ferdinand Porsche tarafından kurulmuş ve ismini de buradan almıştır. Bugüne gelindiği zaman yarış arabası konsepti yerini biraz daha lüks SUV modellerine bırakmıştır.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "Sportif araç deneyimi denildiği zaman ilk akla gelen markaların başında olan Alman otomobil markası Posche, 1931 yılında kurulmuştur. Bugün Volkswagen AG çatısında bulunan lüks otomobil markası, Ferdinand Porsche tarafından kurulmuş ve ismini de buradan almıştır. Bugüne gelindiği zaman yarış arabası konsepti yerini biraz daha lüks SUV modellerine bırakmıştır."
        return sonuc
    elif "47 Proton" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\proton.jpg")
        
        print("1983 yılında kurulan Proton, Malezya menşeili bir markadır. Döneminde oldukça popüler olan bir marka olmasıyla beraber şuan için ülkemizde satışı yoktur.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "1983 yılında kurulan Proton, Malezya menşeili bir markadır. Döneminde oldukça popüler olan bir marka olmasıyla beraber şuan için ülkemizde satışı yoktur."
        return sonuc
    elif "48 Renault" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\Reno.jpg")
        
        print("1898 yılında temelleri atılan Renault bugün geldiği noktada, tüm dünyada bilinen ve popülaritesi yüksek bir marka haline gelmiştir. Pek çok alanda üretim yapan marka, ülkemizde binek ve ticari grupta satışlar yapmaktadır. Fransız otomobil markası olan Renault, Nissan ile bir ortaklığı bulunmaktadır. Bu birleşime Mitsubishi markası da katılmıştır.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "1898 yılında temelleri atılan Renault bugün geldiği noktada, tüm dünyada bilinen ve popülaritesi yüksek bir marka haline gelmiştir. Pek çok alanda üretim yapan marka, ülkemizde binek ve ticari grupta satışlar yapmaktadır. Fransız otomobil markası olan Renault, Nissan ile bir ortaklığı bulunmaktadır. Bu birleşime Mitsubishi markası da katılmıştır."
        return sonuc
    elif "49 Rolls Royce" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\Roys.jpg")
        
        print("Lüks otomobil üreticisi Rolls Royce, İngiltere’de kurulmuştur. Oldukça pahalı otomobiller üreten marka, tamamen lüks ve konfor algısı üzerine tasarımlar yapmaktadır. Prestij algısı yüksek otomobiller üreten marka ülkemizde satılmaktadır.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "Lüks otomobil üreticisi Rolls Royce, İngiltere’de kurulmuştur. Oldukça pahalı otomobiller üreten marka, tamamen lüks ve konfor algısı üzerine tasarımlar yapmaktadır. Prestij algısı yüksek otomobiller üreten marka ülkemizde satılmaktadır."
        return sonuc
    elif "50 Rover" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\Rover.jpg")
        
        print("İngiliz otomobil markası Rover, 1968 yılında kurulmuştur. Bir dönem ülkemizde oldukça popüler olan marka, şuan ülkemizde satış yapmamaktadır.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "İngiliz otomobil markası Rover, 1968 yılında kurulmuştur. Bir dönem ülkemizde oldukça popüler olan marka, şuan ülkemizde satış yapmamaktadır."
        return sonuc
    elif "51 Saab" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\saab.jpg")
        
        print("1947 yılında İsveç’te kurulan Saab, oldukça dayanıklı ve güçlü otomobiller üretmek amacıyla kurulmuştur. Volvo gibi araçlarında kullandığı ve sağlamlığı ile bilinen İsveç çeliğini araçlarında kullanmıştır. Bugün üretimi yoktur.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "1947 yılında İsveç’te kurulan Saab, oldukça dayanıklı ve güçlü otomobiller üretmek amacıyla kurulmuştur. Volvo gibi araçlarında kullandığı ve sağlamlığı ile bilinen İsveç çeliğini araçlarında kullanmıştır. Bugün üretimi yoktur."
        return sonuc
    elif "52 Seat" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\seat.jpg")
        
        print("İspanya merkezli bir otomobil markası olan Seat, bugün Volkswagen AG grubu içinde yer almaktadır. Sportif sürüş odaklı tasarımlar ve motor kombinasyonları kullanan marka, 1950 yılında kurulmuştur. Genç kullanıcı kitlesini hedef alan Seat, dinamizmi ön planda tutan tasarımlara imza atmıştır. Volkswagen grubunun altyapısı ile üretilen modeller, ortak motor-şanzıman kombinasyonlarını kullanmaktadır.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "İspanya merkezli bir otomobil markası olan Seat, bugün Volkswagen AG grubu içinde yer almaktadır. Sportif sürüş odaklı tasarımlar ve motor kombinasyonları kullanan marka, 1950 yılında kurulmuştur. Genç kullanıcı kitlesini hedef alan Seat, dinamizmi ön planda tutan tasarımlara imza atmıştır. Volkswagen grubunun altyapısı ile üretilen modeller, ortak motor-şanzıman kombinasyonlarını kullanmaktadır."
        return sonuc
    elif "53 Skoda" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\skoda.jpg") 
        print("Çek Cumhuriyeti merkezli bir otomobil markası olan Skoda, “Simply Clever” mottosu ile hayatı kolaylaştıracak çözümleri araçlarına entegre etmeye çalışıyor. Kullanıcı dostu detaylar ile akılcı çözümler sunan Skoda, Volkswagen AG otomotiv grubu içinde yer almaktadır. 1895 yılında kurulan marka 1991 yılında Volkswagen grubuna katılmıştır.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "Çek Cumhuriyeti merkezli bir otomobil markası olan Skoda, “Simply Clever” mottosu ile hayatı kolaylaştıracak çözümleri araçlarına entegre etmeye çalışıyor. Kullanıcı dostu detaylar ile akılcı çözümler sunan Skoda, Volkswagen AG otomotiv grubu içinde yer almaktadır. 1895 yılında kurulan marka 1991 yılında Volkswagen grubuna katılmıştır."
        return sonuc
    elif "54 Skywell" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\skywell.jpg")
        
        print("Güzel gökyüzü anlamına gelen Skywell, Çin menşeili bir otomobil üreticisidir. 2000’li yıllarda kurulan şirket teknolojik ürünler üreten bir firma iken bugün otomobil üretimi ile pek çok ülkede yüksek satış rakamlarına ulaşmaya başlamıştır. Günümüzde ABD, Meksika, Kanada, Güney Amerika, Avusturya, Almanya, Romanya, Filistin, İsrail, Ürdün ve Türkiye gibi birçok ülkede satılmaktadır. Ülkemizde satışta olan model ET5 isimli tamamen elektrikli araç satışı yapmaktadır.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "Güzel gökyüzü anlamına gelen Skywell, Çin menşeili bir otomobil üreticisidir. 2000’li yıllarda kurulan şirket teknolojik ürünler üreten bir firma iken bugün otomobil üretimi ile pek çok ülkede yüksek satış rakamlarına ulaşmaya başlamıştır. Günümüzde ABD, Meksika, Kanada, Güney Amerika, Avusturya, Almanya, Romanya, Filistin, İsrail, Ürdün ve Türkiye gibi birçok ülkede satılmaktadır. Ülkemizde satışta olan model ET5 isimli tamamen elektrikli araç satışı yapmaktadır."
        return sonuc
    elif "55 Smart" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\smart.jpg")
        
        print("1994 yılında Mercedes-Benz ve Swatch tarafından kurulan marka, küçük şehir otomobilleri üretmektedir. Son dönemde elektrikli modelleri ile gündeme gelen Smart, ikonik bir tasarım yapısına sahiptir. Bugün hala Mercedes-Benz bünyesinde üretilmektedir.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "1994 yılında Mercedes-Benz ve Swatch tarafından kurulan marka, küçük şehir otomobilleri üretmektedir. Son dönemde elektrikli modelleri ile gündeme gelen Smart, ikonik bir tasarım yapısına sahiptir. Bugün hala Mercedes-Benz bünyesinde üretilmektedir."
        return sonuc
    elif "56 Ssangyong" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\ssang.jpg")
        
        print("Güney Koreli otomobil üreticisi Ssangyong aynı zamanda çelik üreticisidir. Otomobillerinde güçlendirilmiş çelik kullandığını beyan eden marka, SUV ve pick-up modelleri ile ülkemizde tanınmıştır. Koranda ve Musso Grand modelleri ile ülkemizde satışta olan model, 2005 yılında tanıttığı Kyron modelinde Mercedes-Benz ile ortak çalışmış ve motor şanzıman olarak Mercedes-Benz parçaları kullanmıştır.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "Güney Koreli otomobil üreticisi Ssangyong aynı zamanda çelik üreticisidir. Otomobillerinde güçlendirilmiş çelik kullandığını beyan eden marka, SUV ve pick-up modelleri ile ülkemizde tanınmıştır. Koranda ve Musso Grand modelleri ile ülkemizde satışta olan model, 2005 yılında tanıttığı Kyron modelinde Mercedes-Benz ile ortak çalışmış ve motor şanzıman olarak Mercedes-Benz parçaları kullanmıştır."
        return sonuc
    elif "57 Subaru" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\subaru.jpg")
        
        print("Japonya markası olan Subaru, 1953 yılında kurulmuştur. Özellikle yarış otomobilleri üreten marka, bugüne gelindiği zaman elektrikli SUV modellerine ağırlık vermiştir. Lüks segment araç tasarımları konusunda dikkat çekici modeller üreten marka, Japon otomobil severler tarafından oldukça sevilmektedir.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "Japonya markası olan Subaru, 1953 yılında kurulmuştur. Özellikle yarış otomobilleri üreten marka, bugüne gelindiği zaman elektrikli SUV modellerine ağırlık vermiştir. Lüks segment araç tasarımları konusunda dikkat çekici modeller üreten marka, Japon otomobil severler tarafından oldukça sevilmektedir."
        return sonuc
    elif "58 suzuki" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\suzuki.jpg")
        
        print("Japon otomobil üreticisi Suzuki, tarihi 1909 yılına kadar uzanan bir otomobil markasıdır. Aynı zamanda tanınan bir motosiklet üreticisi olan marka, Hibrit otomobiller üreterek günün teknolojisini yakalamıştır. ‘Way of Life!’ mottosu ile kullanıcılarına akılcı çözümler sunan marka, pek çok ülkeye otomobil ihraç etmektedir.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "Japon otomobil üreticisi Suzuki, tarihi 1909 yılına kadar uzanan bir otomobil markasıdır. Aynı zamanda tanınan bir motosiklet üreticisi olan marka, Hibrit otomobiller üreterek günün teknolojisini yakalamıştır. ‘Way of Life!’ mottosu ile kullanıcılarına akılcı çözümler sunan marka, pek çok ülkeye otomobil ihraç etmektedir."
        return sonuc
    elif "59 Tata" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\Tata.jpg")
        
        print("Hindistan merkezli otomobil markası olan Tata 1868 yılında kurulmuştur. Merkezi Mumbai’de olan marka pek çok farklı sektörde faaliyet gösteren bir şirkettir. Türkiye’deki disbiritörlüğünü İsotlar grubun yaptığı Tata, bugün yeni bir model satışı sunmamaktadır.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "Hindistan merkezli otomobil markası olan Tata 1868 yılında kurulmuştur. Merkezi Mumbai’de olan marka pek çok farklı sektörde faaliyet gösteren bir şirkettir. Türkiye’deki disbiritörlüğünü İsotlar grubun yaptığı Tata, bugün yeni bir model satışı sunmamaktadır."
        return sonuc
    elif "60 TOGG" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\Togg.jpg")
        
        print("Türkiye'nin Otomobili Girişim Grubu veya kısaca Togg, Türkiye merkezli bir otomobil üretici şirkettir. Şirket, fikrî mülkiyet haklarına sahip olduğu ilk otomobilini 29 Ekim 2022 seri üretime hazır hâle geldi.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "Türkiye'nin Otomobili Girişim Grubu veya kısaca Togg, Türkiye merkezli bir otomobil üretici şirkettir. Şirket, fikrî mülkiyet haklarına sahip olduğu ilk otomobilini 29 Ekim 2022 seri üretime hazır hâle geldi."
        return sonuc
    elif "61 Toyota" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\Toyota.jpg")
        
        print("Japon otomobil üreticisi Toyota, küresel anlamda en çok otomobil satan markaların başında geliyor. Pek çok farklı segmentte araç üreten Toyota, elektrikli otomobil üretimi konusunda büyük yol almış bir markadır.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "Japon otomobil üreticisi Toyota, küresel anlamda en çok otomobil satan markaların başında geliyor. Pek çok farklı segmentte araç üreten Toyota, elektrikli otomobil üretimi konusunda büyük yol almış bir markadır."
        return sonuc
    elif "62 Volkswagen" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\Vos.jpg")
        
        print("Alman otomobilleri denildiği zaman ilk akla gelen markalardan birisi olan Volkswagen, dünyanın en büyük otomobil grubundan birisidir. 1937 yılında kurulan marka binek ve ticari araç satışını eş zamanlı yapmaktadır.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM") 
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "Alman otomobilleri denildiği zaman ilk akla gelen markalardan birisi olan Volkswagen, dünyanın en büyük otomobil grubundan birisidir. 1937 yılında kurulan marka binek ve ticari araç satışını eş zamanlı yapmaktadır."
        return sonuc
    elif "63 Volvo" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\Volvo.jpg")
        
        print("İsveçli üretici Volvo, sağlamlık konusunda tüm dünyada ün yapmış bir markadır. Özellikle güvenlik konusu üzerinde yoğunlaşan marka, 3 gölgeli emniyet kemerini icat etmiş ve bunu dünya ile ücret talep etmeden paylaşmıştır. 1927 yılında kurulan marka, bugün ürettiği otomobiller ile lüks segment algısını otomobillerinde göstermektedir. Ticari araçlar konusunda da oldukça popüler olan Volvo, yük taşımacılığı için kullanılan tırları oldukça popülerdir.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "İsveçli üretici Volvo, sağlamlık konusunda tüm dünyada ün yapmış bir markadır. Özellikle güvenlik konusu üzerinde yoğunlaşan marka, 3 gölgeli emniyet kemerini icat etmiş ve bunu dünya ile ücret talep etmeden paylaşmıştır. 1927 yılında kurulan marka, bugün ürettiği otomobiller ile lüks segment algısını otomobillerinde göstermektedir. Ticari araçlar konusunda da oldukça popüler olan Volvo, yük taşımacılığı için kullanılan tırları oldukça popülerdir."
        return sonuc
    elif "64 TESLA" in class_name:
        print("TAHMİNİM:arabadc\sonuclar\Tesla.jpg")
        
        print("Tesla, Palo, Alto, California'da bulunan ve elektrikli araç üreten bir şirkettir. Şirketin amacı, günlük tüketiciler için premium veya uygun fiyatlı elektrikli otomobiller üretmektir. Şirket CEO ve kurucusu olan Elon Musk tarafından yönetiliyor. Elektrikli araçların dışında Tesla, daha geniş bir ekosistemi keşfediyor.")
        orn = Image.open(ornek)
        orn.show()
        print("TAHMİN ETMEM İSTENEN RESİM")
        sonuc = "sınıf: " + class_name[2:] + "\n" + "Doğruluk Oranı: %" + str(confidence_score*100) + "\n" + "Tesla, Palo, Alto, California'da bulunan ve elektrikli araç üreten bir şirkettir. Şirketin amacı, günlük tüketiciler için premium veya uygun fiyatlı elektrikli otomobiller üretmektir. Şirket CEO ve kurucusu olan Elon Musk tarafından yönetiliyor. Elektrikli araçların dışında Tesla, daha geniş bir ekosistemi keşfediyor."
        return sonuc
       
    

